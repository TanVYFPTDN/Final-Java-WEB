/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author letan
 */
public interface Databaseinfo {
    public static String driverName= "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    public static String dbURL="jdbc:sqlserver://localhost:1433;databaseName=Final;";
    public static String userDB="sa";
    public static String passDB="110317";
}
