
package model;

import java.util.Date;

public class LognoptienTBL {
    private int accno;
    private int uid;
    private Date ngaynop;
    private int sotien;
    private String phuongthuc;

    public LognoptienTBL() {
    }

    public LognoptienTBL(int accno, int uid, Date ngaynop, int sotien, String phuongthuc) {
        this.accno = accno;
        this.uid = uid;
        this.ngaynop = ngaynop;
        this.sotien = sotien;
        this.phuongthuc = phuongthuc;
    }

    public int getAccno() {
        return accno;
    }

    public void setAccno(int accno) {
        this.accno = accno;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public Date getNgaynop() {
        return ngaynop;
    }

    public void setNgaynop(Date ngaynop) {
        this.ngaynop = ngaynop;
    }

    public int getSotien() {
        return sotien;
    }

    public void setSotien(int sotien) {
        this.sotien = sotien;
    }

    public String getPhuongthuc() {
        return phuongthuc;
    }

    public void setPhuongthuc(String phuongthuc) {
        this.phuongthuc = phuongthuc;
    }
    
    
    
    
}
