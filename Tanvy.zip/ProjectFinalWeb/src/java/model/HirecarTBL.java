/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.Date;

/**
 *
 * @author letan
 */
public class HirecarTBL {
    private int Hirecarid;
    private String bienso;
    private Date startrent;
    private Date endrent;
    private String comment;
    private String location;
    private String loaihinh;
    private int giaxechothue;

    public HirecarTBL() {
    }

    public HirecarTBL(int Hirecarid, String bienso, Date startrent, Date endrent, String comment, String location, String loaihinh, int giaxechothue) {
        this.Hirecarid = Hirecarid;
        this.bienso = bienso;
        this.startrent = startrent;
        this.endrent = endrent;
        this.comment = comment;
        this.location = location;
        this.loaihinh = loaihinh;
        this.giaxechothue = giaxechothue;
    }

    public int getHirecarid() {
        return Hirecarid;
    }

    public void setHirecarid(int Hirecarid) {
        this.Hirecarid = Hirecarid;
    }

    public String getBienso() {
        return bienso;
    }

    public void setBienso(String bienso) {
        this.bienso = bienso;
    }

    public Date getStartrent() {
        return startrent;
    }

    public void setStartrent(Date startrent) {
        this.startrent = startrent;
    }

    public Date getEndrent() {
        return endrent;
    }

    public void setEndrent(Date endrent) {
        this.endrent = endrent;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getLoaihinh() {
        return loaihinh;
    }

    public void setLoaihinh(String loaihinh) {
        this.loaihinh = loaihinh;
    }

    public int getGiaxechothue() {
        return giaxechothue;
    }

    public void setGiaxechothue(int giaxechothue) {
        this.giaxechothue = giaxechothue;
    }
    
    
}
