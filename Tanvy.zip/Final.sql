create database Final
use Final
--
create table UserTBL
		(uid int identity(1,1) primary key,sotaikhoan int , 
		phonenb varchar(12) not null, pass varchar(12) not null,
		fname varchar(100) not null, email varchar(100), 
		address varchar(100),lock bit default(0) )
--
create table CarTBL
		(bienso varchar(12) primary key not null,uid int not null,
		socho int not null,hangxe varchar(20) not null,
		loainguyenlieu varchar(20),hopso varchar(20), anhxe image not null, 
		giaytoxe image not null, lichkiemtra datetime not null, 
		status varchar(20) not null,tinhnangxe varchar(100) not null,
		tienchothue int not null,tiencoc int)
--
create table HirecarTBL
		(Hirecarid int identity(1,1) not null primary key,
		bienso varchar(12) not null, startrent date not null, 
		endrent date not null, comment varchar(100),
		location varchar(100) not null, loaihinh varchar(10), giaxechothue int not null)
--
create table OrderTBL
		(oid int identity(1,1) not null primary key,
		uid int not null,Hirecarid int not null, 
		start datetime not null, endrent datetime not null, 
		ngaynhan datetime,ngaytra datetime,
		ghichu varchar(100),tongtien int not null)
--
create table LognoptienTBL
		(accno int identity(1,1) primary key, uid int not null, 
		ngaynop datetime not null, sotien decimal(20,2) not null, 
		phuongthuc varchar(20))

 --------------------
ALTER TABLE CarTBL	
ADD CONSTRAINT FK_Dangkixe FOREIGN KEY(uid)
References UserTBL(uid)
--------------------
ALTER TABLE LognoptienTBL	
ADD CONSTRAINT FK_log FOREIGN KEY(uid)
References UserTBL(uid)
--------------------
ALTER TABLE HirecarTBL	
ADD CONSTRAINT FK_dangbai FOREIGN KEY(bienso)
References CarTBL(bienso)
----------------------
ALTER TABLE OrderTBL	
ADD CONSTRAINT FK_order FOREIGN KEY(Hirecarid)
References HirecarTBL(Hirecarid)
--------------------
ALTER TABLE OrderTBL	
ADD CONSTRAINT FK_rent FOREIGN KEY(uid)
References UserTBL(uid)

--------------
ALTER TABLE CarTBL
DROP CONSTRAINT FK_Dangkixe
ALTER TABLE LognoptienTBL
DROP CONSTRAINT FK_log
ALTER TABLE HirecarTBL
DROP CONSTRAINT FK_dangbai
ALTER TABLE OrderTBL
DROP CONSTRAINT FK_order,FK_rent

------------------
Drop table UserTBL,CarTBL,HirecarTBL,OrderTBL,LognoptienTBL
select * from UserTBL