
package model;

import model.UserTBLDB;


public class UserTBL {
    private int uid;
    private String sotaikhoan;
    private String phonenb;
    private String pass;
    private String fname;
    private String email;
    private String address;
    private boolean lock;

    public UserTBL(int uid, String sotaikhoan, String phonenb, String pass, String fname, String email, String address, boolean lock) {
        this.uid = uid;
        this.sotaikhoan = sotaikhoan;
        this.phonenb = phonenb;
        this.pass = pass;
        this.fname = fname;
        this.email = email;
        this.address = address;
        this.lock = lock;
    }


   public UserTBL(String phone) {
       UserTBLDB st = new UserTBLDB();
       UserTBL s = st.getUser(st.getuid(phone));
       if(s==null){
           
       }
        this.uid = s.uid;
        this.sotaikhoan = s.sotaikhoan;
        this.phonenb = s.phonenb;
        this.pass = s.pass;
        this.fname = s.fname;
        this.email = s.email;
        this.address = s.address;
        this.lock = s.lock;
    }
    public UserTBL() {
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public String getSotaikhoan() {
        return sotaikhoan;
    }

    public void setSotaikhoan(String sotaikhoan) {
        this.sotaikhoan = sotaikhoan;
    }

    public String getPhonenb() {
        return phonenb;
    }

    public void setPhonenb(String phonenb) {
        this.phonenb = phonenb;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int isLock() {
         if(lock== true){
            return 1;
        }
        else return 0;
    }

    public void setLock(String lock) {
         if(lock.equals("True")){
            this.lock =true;
        }
        else {
            this.lock= false;
        }
    }

    @Override
    public String toString() {
        return "UserTBL{" + "uid=" + uid + ", sotaikhoan=" + sotaikhoan + ", phonenb=" + phonenb + ", pass=" + pass + ", fname=" + fname + ", email=" + email + ", address=" + address + ", lock=" + lock + '}';
    }
    //==============================================
     public UserTBL login(String phone, String pass){
      UserTBL s = new UserTBL(phone);
      if(s.pass.equals(pass)) return s;
      return null;
    }
     //================================================
         public   boolean changePass(String oldP, String newP){
        if(pass.equals(oldP)){
            pass=newP;
            UserTBLDB s= new UserTBLDB();
            return s.updateUser(this);
        }
        return false;
    }
         //=========================
public boolean changePhoneNb(String oldphoneNB,String newphoneNB){
        if(phonenb.equals(oldphoneNB)){
            email=newphoneNB;
            UserTBLDB s= new UserTBLDB();
            return s.updateUser(this);
        }
        return false;
    }
    public static void main(String[] args) {
        UserTBL st = new UserTBL();
        System.out.println(st.login("0349880019","123456789"));
    }
}
