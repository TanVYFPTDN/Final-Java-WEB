/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.Date;

/**
 *
 * @author letan
 */
public class OrderTBL {
    private int oid;
    private int uid;
    private int Hirecarid;
    private Date startrent;
    private Date endrent;
    private int tiencoc;
    private Date ngaynhan;
    private Date ngaytra;
    private String ghichu;
    private int tongtien;

    public OrderTBL() {
    }

    public OrderTBL(int oid, int uid, int Hirecarid, Date startrent, Date endrent, int tiencoc, Date ngaynhan, Date ngaytra, String ghichu, int tongtien) {
        this.oid = oid;
        this.uid = uid;
        this.Hirecarid = Hirecarid;
        this.startrent = startrent;
        this.endrent = endrent;
        this.tiencoc = tiencoc;
        this.ngaynhan = ngaynhan;
        this.ngaytra = ngaytra;
        this.ghichu = ghichu;
        this.tongtien = tongtien;
    }

    public int getOid() {
        return oid;
    }

    public void setOid(int oid) {
        this.oid = oid;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public int getHirecarid() {
        return Hirecarid;
    }

    public void setHirecarid(int Hirecarid) {
        this.Hirecarid = Hirecarid;
    }

    public Date getStartrent() {
        return startrent;
    }

    public void setStartrent(Date startrent) {
        this.startrent = startrent;
    }

    public Date getEndrent() {
        return endrent;
    }

    public void setEndrent(Date endrent) {
        this.endrent = endrent;
    }

    public int getTiencoc() {
        return tiencoc;
    }

    public void setTiencoc(int tiencoc) {
        this.tiencoc = tiencoc;
    }

    public Date getNgaynhan() {
        return ngaynhan;
    }

    public void setNgaynhan(Date ngaynhan) {
        this.ngaynhan = ngaynhan;
    }

    public Date getNgaytra() {
        return ngaytra;
    }

    public void setNgaytra(Date ngaytra) {
        this.ngaytra = ngaytra;
    }

    public String getGhichu() {
        return ghichu;
    }

    public void setGhichu(String ghichu) {
        this.ghichu = ghichu;
    }

    public int getTongtien() {
        return tongtien;
    }

    public void setTongtien(int tongtien) {
        this.tongtien = tongtien;
    }
    
    
    
}
