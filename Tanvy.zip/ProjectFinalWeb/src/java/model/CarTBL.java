/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.Date;

public class CarTBL {
    private int bienso;
    private int uid;
    private int socho;
    private String hangxe;
    private String loainguyenlieu;
    private String hopso;
    private byte[] anhxe;
    private byte[]giaytoxe ;
    private String thuoctinh;
    private Date lichkiemtra;
    private String status;
    private String tinhnangxe;
    private int tienchothue;
    private int tiencoc;

    public CarTBL() {
    }

    public CarTBL(int bienso, int uid, int socho, String hangxe, String loainguyenlieu, String hopso, byte[] anhxe, byte[] giaytoxe, String thuoctinh, Date lichkiemtra, String status, String tinhnangxe, int tienchothue, int tiencoc) {
        this.bienso = bienso;
        this.uid = uid;
        this.socho = socho;
        this.hangxe = hangxe;
        this.loainguyenlieu = loainguyenlieu;
        this.hopso = hopso;
        this.anhxe = anhxe;
        this.giaytoxe = giaytoxe;
        this.thuoctinh = thuoctinh;
        this.lichkiemtra = lichkiemtra;
        this.status = status;
        this.tinhnangxe = tinhnangxe;
        this.tienchothue = tienchothue;
        this.tiencoc = tiencoc;
    }

    public int getBienso() {
        return bienso;
    }

    public void setBienso(int bienso) {
        this.bienso = bienso;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public int getSocho() {
        return socho;
    }

    public void setSocho(int socho) {
        this.socho = socho;
    }

    public String getHangxe() {
        return hangxe;
    }

    public void setHangxe(String hangxe) {
        this.hangxe = hangxe;
    }

    public String getLoainguyenlieu() {
        return loainguyenlieu;
    }

    public void setLoainguyenlieu(String loainguyenlieu) {
        this.loainguyenlieu = loainguyenlieu;
    }

    public String getHopso() {
        return hopso;
    }

    public void setHopso(String hopso) {
        this.hopso = hopso;
    }

    public byte[] getAnhxe() {
        return anhxe;
    }

    public void setAnhxe(byte[] anhxe) {
        this.anhxe = anhxe;
    }

    public byte[] getGiaytoxe() {
        return giaytoxe;
    }

    public void setGiaytoxe(byte[] giaytoxe) {
        this.giaytoxe = giaytoxe;
    }

    public String getThuoctinh() {
        return thuoctinh;
    }

    public void setThuoctinh(String thuoctinh) {
        this.thuoctinh = thuoctinh;
    }

    public Date getLichkiemtra() {
        return lichkiemtra;
    }

    public void setLichkiemtra(Date lichkiemtra) {
        this.lichkiemtra = lichkiemtra;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTinhnangxe() {
        return tinhnangxe;
    }

    public void setTinhnangxe(String tinhnangxe) {
        this.tinhnangxe = tinhnangxe;
    }

    public int getTienchothue() {
        return tienchothue;
    }

    public void setTienchothue(int tienchothue) {
        this.tienchothue = tienchothue;
    }

    public int getTiencoc() {
        return tiencoc;
    }

    public void setTiencoc(int tiencoc) {
        this.tiencoc = tiencoc;
    }
    
}
