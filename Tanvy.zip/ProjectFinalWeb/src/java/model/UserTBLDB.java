/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Databaseinfo;
import model.UserTBL;

/**
 *
 * @author letan
 */
public class UserTBLDB implements  Databaseinfo{
    public  boolean addNewUser(String phonenb, String pass,String fullname, String email, String address){
        try {
            Class.forName(driverName);
            Connection con = DriverManager.getConnection(dbURL,userDB,passDB);
            PreparedStatement stmt= con.prepareStatement("Insert into UserTBL(phonenb,pass,fname,email,address) values(?,?,?,?,?)");
            stmt.setString(1, phonenb);
            stmt.setString(2, pass);
            stmt.setString(3, fullname); 
            stmt.setString(4, email);
            stmt.setString(5, address);
            stmt.executeUpdate();
            con.close();
        } catch (Exception ex) {
            Logger.getLogger(UserTBLDB.class.getName()).log(Level.SEVERE, null, ex);
          return false;
        }
           return true;
    }
        public  boolean updateUser(UserTBL s){
        try {
            Class.forName(driverName);
            Connection con = DriverManager.getConnection(dbURL,userDB,passDB);
            PreparedStatement stmt= con.prepareStatement("Update UserTBL set phonenb=?,fname=?,pass=?,email=?,address=?, lock=?,sotaikhoan=? where uid=?");
            stmt.setString(1, s.getPhonenb());
            stmt.setString(2, s.getFname());
            stmt.setString(3, s.getPass());
            stmt.setString(4, s.getEmail());
            stmt.setString(5, s.getAddress());
            stmt.setInt(6, s.isLock()); 
            stmt.setString(7, s.getSotaikhoan()); 
            stmt.setInt(8, s.getUid());
            int rc=stmt.executeUpdate();
            con.close();
            return rc==1;
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return false;
    }
     public  UserTBL getUser(int uid){
        UserTBL s=null;
        try {
            Class.forName(driverName);
            Connection con = DriverManager.getConnection(dbURL,userDB,passDB);
            Statement stmt= con.createStatement();
            ResultSet rs=stmt.executeQuery("Select sotaikhoan,phonenb,fname,pass,email,address,lock from UserTBL where uid='"+uid+"'");
            if(rs.next()){
                String sotaikhoan = rs.getString(1);
                String phonenb = rs.getString(2);
                String fname=rs.getString(3);
                String pass=rs.getString(4);
                String email=rs.getString(5);
                String address=rs.getString(6);
                int testlock=rs.getInt(7);
                boolean lock;
                if(testlock==1){
                    lock= true;
                }
                else{
                    lock = false;
                }
                s=new UserTBL(uid, sotaikhoan, phonenb, pass, fname, email, address, lock);
            }
            con.close();
            return s;
        } catch (Exception ex) {
            Logger.getLogger(UserTBLDB.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
         public  int getuid(String phonenb){
        int uid=0;
        try {
            Class.forName(driverName);
            Connection con = DriverManager.getConnection(dbURL,userDB,passDB);
            PreparedStatement stmt= con.prepareStatement("select uid from UserTBL where phonenb='"+phonenb+"'");
            ResultSet rs = stmt.executeQuery();
             while(rs.next()){
                 uid = rs.getInt(1);
             }
             con.close();
        } catch (Exception ex) {
            Logger.getLogger(UserTBLDB.class.getName()).log(Level.SEVERE, null, ex);
        }
        return uid;
    }
         public static void main(String[] args) {
        UserTBLDB us = new UserTBLDB();
             System.out.println(us.addNewUser("0984535611","123","Lê Tấn Vỹ","abc@abc.com","Hương An"));
    }
}
